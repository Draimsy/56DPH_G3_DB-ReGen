# detect.py
import sqlite3
import re

def detect_issue(db_path="uploaded_db.db"):
    """
    Detects schema and data issues in the uploaded SQLite DB.
    Returns a list of detected issues.
    """
    issues = []

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [t[0] for t in cursor.fetchall()]
        if not tables:
            issues.append("No tables found in database")
            return issues

        for table in tables:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = [col[1] for col in cursor.fetchall()]
            if not columns:
                issues.append(f"Table '{table}' has no columns")
                continue

            # Null IDs
            if "id" in columns:
                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE id IS NULL")
                null_ids = cursor.fetchone()[0]
                if null_ids > 0:
                    issues.append(f"Table '{table}': {null_ids} rows with NULL IDs")

                # Duplicate IDs
                cursor.execute(f"SELECT id, COUNT(*) FROM {table} GROUP BY id HAVING COUNT(*) > 1")
                dup_ids = cursor.fetchall()
                if dup_ids:
                    issues.append(f"Table '{table}': {len(dup_ids)} duplicate IDs found")

                # String IDs
                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE typeof(id) != 'integer'")
                string_ids = cursor.fetchone()[0]
                if string_ids > 0:
                    issues.append(f"Table '{table}': {string_ids} IDs are not integers")

            # Null Emails
            if "email" in columns:
                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE email IS NULL")
                null_emails = cursor.fetchone()[0]
                if null_emails > 0:
                    issues.append(f"Table '{table}': {null_emails} rows with NULL email")

                # Invalid emails
                cursor.execute(f"SELECT email FROM {table} WHERE email IS NOT NULL")
                all_emails = [row[0] for row in cursor.fetchall()]
                invalid_emails = [e for e in all_emails if not re.match(r"^[^@]+@[^@]+\.[^@]+$", str(e))]
                if invalid_emails:
                    issues.append(f"Table '{table}': {len(invalid_emails)} invalid email(s)")

            # Age checks
            if "age" in columns:
                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE age IS NULL")
                null_age = cursor.fetchone()[0]
                if null_age > 0:
                    issues.append(f"Table '{table}': {null_age} rows with NULL age")

                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE age < 0")
                neg_age = cursor.fetchone()[0]
                if neg_age > 0:
                    issues.append(f"Table '{table}': {neg_age} rows with negative age")

                cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE age > 120")
                ill_age = cursor.fetchone()[0]
                if ill_age > 0:
                    issues.append(f"Table '{table}': {ill_age} rows with illogical age (>120)")

            # Empty table
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            if cursor.fetchone()[0] == 0:
                issues.append(f"Table '{table}' is empty")

    except Exception as e:
        issues.append(f"Error inspecting DB: {e}")

    finally:
        conn.close()

    return issues if issues else ["No issues detected, database looks healthy"]

# Helper: schema summary for LLM
def generate_schema_summary(db_path="uploaded_db.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    summary = ""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [t[0] for t in cursor.fetchall()]
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = cursor.fetchall()
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        row_count = cursor.fetchone()[0]
        summary += f"Table: {table}\n"
        summary += "Columns: " + ", ".join([f"{col[1]} ({col[2]})" for col in columns]) + "\n"
        summary += f"Row count: {row_count}\n\n"
    conn.close()
    return summary
