import sqlite3

def execute_fix(sql_commands, db_path="uploaded_db.db"):
    """
    Executes SQL commands in SQLite.
    Accepts multiple statements in a single string using executescript().
    Returns True on success, False otherwise.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        if isinstance(sql_commands, str):
            sql_commands = [sql_commands]
        for cmd in sql_commands:
            cursor.executescript(cmd)  # allow multiple statements
        conn.commit()
        return True
    except Exception as e:
        conn.rollback()
        print(f"Execution failed: {e}")
        return False
    finally:
        conn.close()
