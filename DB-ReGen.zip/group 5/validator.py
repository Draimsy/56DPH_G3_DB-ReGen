# validator.py
import sqlite3
import re

def validate_db(db_path: str):
    """
    Checks the database for common errors:
    NULL IDs, duplicates, invalid emails, invalid ages.
    Returns (ok: bool, issues: list[str])
    """
    issues = []
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Detect tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [t[0] for t in cursor.fetchall()]

    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        cols = {c[1]: c[2] for c in cursor.fetchall()}

        # IDs
        if "id" in cols:
            cursor.execute(f"SELECT COUNT(*) FROM {table} WHERE id IS NULL")
            null_ids = cursor.fetchone()[0]
            if null_ids > 0:
                issues.append(f"Table '{table}': {null_ids} rows with NULL IDs")

            cursor.execute(f"SELECT id, COUNT(*) FROM {table} GROUP BY id HAVING COUNT(*)>1")
            dup_ids = cursor.fetchall()
            if dup_ids:
                issues.append(f"Table '{table}': {len(dup_ids)} duplicate IDs found")

            cursor.execute(f"SELECT id FROM {table}")
            for row in cursor.fetchall():
                try:
                    int(row[0])
                except:
                    issues.append(f"Table '{table}': ID '{row[0]}' is not an integer")

        # Emails
        if "email" in cols:
            cursor.execute(f"SELECT email FROM {table} WHERE email IS NULL")
            null_emails = len(cursor.fetchall())
            if null_emails > 0:
                issues.append(f"Table '{table}': {null_emails} rows with NULL email")

            cursor.execute(f"SELECT email FROM {table} WHERE email IS NOT NULL")
            invalid = 0
            for email, in cursor.fetchall():
                if email.count("@") != 1:
                    invalid += 1
            if invalid > 0:
                issues.append(f"Table '{table}': {invalid} invalid email(s)")

        # Ages
        if "age" in cols:
            cursor.execute(f"SELECT age FROM {table}")
            null_age = 0
            neg_age = 0
            illogical = 0
            for age, in cursor.fetchall():
                if age is None:
                    null_age += 1
                else:
                    try:
                        a = int(age)
                        if a < 0:
                            neg_age += 1
                        if a > 120:
                            illogical += 1
                    except:
                        null_age += 1
            if null_age > 0:
                issues.append(f"Table '{table}': {null_age} rows with NULL age")
            if neg_age > 0:
                issues.append(f"Table '{table}': {neg_age} rows with negative age")
            if illogical > 0:
                issues.append(f"Table '{table}': {illogical} rows with illogical age (>120)")

    conn.close()
    ok = len(issues) == 0
    return ok, issues
