import subprocess

OLLAMA_PATH = r"C:\Users\cyril\AppData\Local\Programs\Ollama\ollama.exe"
MODEL_NAME = "phi3"

def plan_fix(issues: list[str], schema_summary: str) -> str:
    prompt = f"""
You are a professional SQL fixer.

The database schema is:

{schema_summary}

Detected issues:
{chr(10).join(issues)}

Write a single SQL script that fixes all issues.
Use SQLite syntax.
Only output SQL statements. No explanations.
"""
    try:
        process = subprocess.run(
            [
                OLLAMA_PATH,
                "run",
                MODEL_NAME
            ],
            input=prompt,
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes
        )

        if process.returncode != 0:
            return f"-- Ollama error:\n{process.stderr.strip()}"

        sql = process.stdout.strip()
        if not sql:
            return "-- Ollama returned empty SQL output"
        return sql

    except subprocess.TimeoutExpired:
        return "-- Ollama exception: timed out waiting for model response"
    except Exception as e:
        return f"-- Ollama exception: {str(e)}"
