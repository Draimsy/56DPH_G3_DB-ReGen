import os
print(os.getenv("GOOGLE_APPLICATION_CREDENTIALS"))

