# MCP.py
from executor import execute_fix

VALID_KEYWORDS = ("CREATE", "ALTER", "UPDATE", "DELETE", "INSERT")

def execute_plan(plan: str, db_path="uploaded_db.db") -> str:
    """
    Executes SQL statements via MCP safely for SQLite.
    Skips unsupported statements.
    Returns detailed log.
    """
    log_entries = []

    if not plan.strip():
        return "MCP: No SQL plan provided."

    statements = [stmt.strip() for stmt in plan.split(";") if stmt.strip()]

    for stmt in statements:
        if not stmt.upper().startswith(VALID_KEYWORDS):
            log_entries.append(f"MCP: Skipped unsupported statement -> {stmt}")
            continue

        try:
            success = execute_fix(stmt + ";", db_path=db_path)
            if success:
                log_entries.append(f"MCP: Executed -> {stmt}")
            else:
                log_entries.append(f"MCP: Execution failed -> {stmt}")
        except Exception as e:
            log_entries.append(f"MCP: Exception on '{stmt}': {str(e)}")

    return "\n".join(log_entries)
