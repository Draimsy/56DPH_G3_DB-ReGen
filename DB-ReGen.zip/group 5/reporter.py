# reporter.py

def report_result(message: str):
    """
    Simple mock reporting function.
    Prints messages or logs them.
    """
    print(message)


# Optional detailed logging for multiple steps
def log_report(issue: str, plan: str, execution_result: str, validation_result: str) -> None:
    """
    Mock logger to report the full pipeline actions.
    """
    print("Logged Report:")
    print("Issue:", issue)
    print("Plan:", plan)
    print("Execution Result:", execution_result)
    print("Validation Result:", validation_result)


# Simple test
if __name__ == "__main__":
    report_result("Test: Reporting a simple message.")
    issue = "Missing table: users"
    plan = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY);"
    execution_result = "MCP: Successfully executed plan"
    validation_result = "Validation: Issue 'users' resolved successfully"
    log_report(issue, plan, execution_result, validation_result)
