from detect import detect_issue, generate_schema_summary
from planner import plan_fix
from MCP import execute_plan
from executor import execute_fix
from reporter import report_result

DB_PATH = "uploaded_db.db"  # Make sure this points to your uploaded DB

def main():
    # Step 1: Detect issues
    issues = detect_issue(DB_PATH)
    if not issues:
        report_result("No issues detected.")
        return

    for issue in issues:
        report_result(f"Issue detected: {issue}")

    # Step 2: Generate schema summary
    schema_summary = generate_schema_summary(DB_PATH)

    # Step 3: Generate SQL fix using planner (Ollama)
    plan = plan_fix(issues, schema_summary)
    report_result("Generated SQL Fix:\n" + plan)

    # Step 4: Execute SQL fix via MCP
    plan_result = execute_plan(plan, db_path=DB_PATH)
    report_result("MCP Execution:\n" + str(plan_result))

    # Step 5: Validate DB after fix
    post_issues = detect_issue(DB_PATH)
    if len(post_issues) == 1 and "No issues detected" in post_issues[0]:
        report_result("Validation passed: database looks healthy.")
    else:
        report_result("Validation detected remaining issues:")
        for issue in post_issues:
            report_result(issue)

if __name__ == "__main__":
    main()
