import streamlit as st
import sqlite3
import pandas as pd
import tempfile
import os
from planner import plan_fix
from MCP import execute_plan
from validator import validate_db

st.set_page_config(page_title="Self-Healing DB Pipeline", layout="wide")
st.title("🚀 Self-Healing Database Pipeline")

# -----------------------------
# DB Upload
# -----------------------------
uploaded_file = st.file_uploader("Upload your SQLite database", type=["db"])
if uploaded_file is None:
    st.warning("Please upload a .db file to continue")
    st.stop()

temp_dir = tempfile.gettempdir()
db_path = os.path.join(temp_dir, uploaded_file.name)
with open(db_path, "wb") as f:
    f.write(uploaded_file.getbuffer())

# -----------------------------
# Schema summary
# -----------------------------
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
schema_summary = ""
for tbl in tables:
    tbl_name = tbl[0]
    cursor.execute(f"PRAGMA table_info({tbl_name})")
    cols = cursor.fetchall()
    col_defs = ", ".join([f"{c[1]} ({c[2]})" for c in cols])
    cursor.execute(f"SELECT COUNT(*) FROM {tbl_name}")
    row_count = cursor.fetchone()[0]
    schema_summary += f"Table: {tbl_name}\nColumns: {col_defs}\nRow count: {row_count}\n\n"
conn.close()

# -----------------------------
# Detect issues
# -----------------------------
st.subheader("Detected Issues")
ok, issues_detected = validate_db(db_path)
issues = []
if not ok:
    issues = issues_detected
    for issue in issues:
        st.warning(issue)
else:
    st.info("No issues detected.")

# -----------------------------
# LLM Plan
# -----------------------------
st.subheader("LLM Generated SQL Fix")
if issues:
    with st.spinner("Generating SQL fix via Ollama..."):
        sql_fix = plan_fix(issues, schema_summary)
        st.code(sql_fix, language="sql")
else:
    sql_fix = ""
    st.info("No SQL fix required.")

# -----------------------------
# MCP Execution
# -----------------------------
st.subheader("MCP Execution")
log_entries = []
if sql_fix:
    with st.spinner("Executing SQL fix via MCP..."):
        execution_log = execute_plan(sql_fix, db_path=db_path)
        st.text(execution_log)
        log_entries.append(execution_log)
else:
    st.info("Nothing to execute.")

# -----------------------------
# Validation After Fix
# -----------------------------
st.subheader("Validation After Fix")
ok, issues_after = validate_db(db_path)
if ok:
    st.success("Database looks healthy after fixes!")
else:
    for i in issues_after:
        st.warning(i)

# -----------------------------
# Download fixed DB
# -----------------------------
st.subheader("Download Fixed Database")
with open(db_path, "rb") as f:
    st.download_button(
        label="📥 Download Fixed DB",
        data=f,
        file_name=f"fixed_{uploaded_file.name}",
        mime="application/x-sqlite3"
    )

# -----------------------------
# Download execution logs
# -----------------------------
st.subheader("Download Execution Logs")
if log_entries:
    logs_text = "\n".join(log_entries)
    st.download_button(
        label="📥 Download Logs",
        data=logs_text,
        file_name=f"execution_logs.txt",
        mime="text/plain"
    )
